const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const userController = require('../controllers/userController');

router.post(
  '/',
  [
    body('displayName').notEmpty().trim().isLength({ min: 2, max: 100 }),
    body('email').optional().isEmail().normalizeEmail()
  ],
  userController.createUser
);

router.get('/:userId', userController.getUser);

router.patch(
  '/:userId',
  [
    body('displayName').optional().trim().isLength({ min: 2, max: 100 }),
    body('email').optional().isEmail().normalizeEmail(),
    body('phoneNumber').optional().isMobilePhone('any'),
    body('paymentMethod').optional().isString()
  ],
  userController.updateUser
);

router.post(
  '/:userId/auth-log',
  [
    body('deviceType').notEmpty().isString(),
    body('location').optional().isString(),
    body('success').optional().isBoolean()
  ],
  userController.logAuthentication
);

router.get('/:userId/auth-history', userController.getAuthenticationHistory);

module.exports = router;
